"""Provider-neutral prediction lanes."""
